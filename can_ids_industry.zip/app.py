from flask import Flask, jsonify
from flask_socketio import SocketIO
from model import predict
import random, time

app = Flask(__name__)
socketio = SocketIO(app)

@app.route("/")
def home():
    return "CAN IDS Running"

def generate_data():
    while True:
        sample = {
            "id": random.randint(100,110),
            "data_length": 8,
            "data": "FFEEAABBCCDDEEFF"
        }
        result = predict(sample)
        socketio.emit('update', {'result': result})
        socketio.sleep(2)

@socketio.on('connect')
def connect():
    socketio.start_background_task(generate_data)

if __name__ == "__main__":
    socketio.run(app, debug=True)
