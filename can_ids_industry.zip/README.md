# Industry-Level CAN IDS Project

Features:
- ML (Isolation Forest) + DL (LSTM Autoencoder)
- Real-time streaming (simulated)
- WebSocket-ready backend
- Advanced dashboard (Chart.js live)
- REST API + Mobile integration
- IEEE paper (full structure)

Run:
pip install -r requirements.txt
python train.py
python app.py
