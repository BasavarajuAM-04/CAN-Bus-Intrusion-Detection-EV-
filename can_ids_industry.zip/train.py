import pandas as pd
from sklearn.ensemble import IsolationForest
import joblib

df = pd.read_csv("data/can_log.csv")
df['data_int'] = df['data'].apply(lambda x:int(x,16))
X = df[['id','data_length','data_int']]

model = IsolationForest(contamination=0.1)
model.fit(X)
joblib.dump(model,"model.pkl")
print("Model trained")
