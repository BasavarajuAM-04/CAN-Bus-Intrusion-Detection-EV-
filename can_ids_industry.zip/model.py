import joblib, pandas as pd
model = joblib.load("model.pkl")

def predict(data):
    df = pd.DataFrame([data])
    df['data_int'] = df['data'].apply(lambda x:int(x,16))
    X = df[['id','data_length','data_int']]
    return "ATTACK" if model.predict(X)[0]==-1 else "NORMAL"
