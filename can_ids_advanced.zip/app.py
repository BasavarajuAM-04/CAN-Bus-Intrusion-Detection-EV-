from flask import Flask, render_template, request
from model import predict

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def index():
    result = None
    if request.method == "POST":
        data = {
            "id": int(request.form["id"]),
            "data_length": int(request.form["length"]),
            "data": request.form["data"]
        }
        result = predict(data)
    return render_template("index.html", result=result)

if __name__ == "__main__":
    app.run(debug=True)
