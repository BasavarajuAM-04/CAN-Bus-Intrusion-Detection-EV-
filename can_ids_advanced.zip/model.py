import joblib
import pandas as pd

model = joblib.load("model.pkl")

def predict(data):
    df = pd.DataFrame([data])
    df['data_int'] = df['data'].apply(lambda x: int(x, 16))
    X = df[['id', 'data_length', 'data_int']]
    pred = model.predict(X)
    return "ATTACK" if pred[0] == -1 else "NORMAL"
