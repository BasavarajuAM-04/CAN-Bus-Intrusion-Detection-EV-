# CAN Bus Intrusion Detection System (Advanced)

## Features
- ML-based anomaly detection (Isolation Forest)
- Flask Web Dashboard
- Real-time prediction
- Clean UI

## Run Instructions
pip install -r requirements.txt
python train.py
python app.py
